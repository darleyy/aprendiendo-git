# Agente de Bienestar/Hábitos

Asistente de IA que ayuda a llevar seguimiento de hábitos saludables (agua, ejercicio, sueño).

## Estructura del proyecto

```
wellness-agent/
├── main.py          # Backend Flask + lógica del agente (Gemini)
├── tools.py         # Las 5 herramientas del agente
├── models.py        # Modelos de datos (registros de hábitos)
├── requirements.txt # Dependencias
├── .env             # API key (NO subir a git)
├── .env.example     # Plantilla de referencia
├── data/            # Aquí se guardan los registros en JSON
└── static/
    └── index.html   # Frontend
```

## Instalación

1. Crear entorno virtual:
   ```
   python -m venv venv
   venv\Scripts\activate   (Windows)
   source venv/bin/activate  (Mac/Linux)
   ```

2. Instalar dependencias:
   ```
   pip install -r requirements.txt
   ```

3. Copiar `.env.example` a `.env` y poner tu API key de Google:
   ```
   GOOGLE_API_KEY=tu_api_key_real
   ```

4. Ejecutar:
   ```
   python main.py
   ```

5. Abrir el navegador en `http://localhost:5000`

## Herramientas del agente

1. **registrar_habito** — Guarda cuando el usuario reporta que hizo algo (tomó agua, ejercicio, durmió X horas).
2. **calcular_progreso** — Analiza los registros para ver el cumplimiento.
3. **sugerir_meta** — Sugiere una meta razonable según el hábito y nivel del usuario.
4. **generar_recordatorio** — Genera un recordatorio para un hábito pendiente.
5. **dar_consejo** — Da un consejo de bienestar basado en patrones detectados.
