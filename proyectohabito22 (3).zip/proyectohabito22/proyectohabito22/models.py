"""
models.py
Define la estructura de los registros de hábitos y las funciones
para leer/guardar los datos en un archivo JSON (por usuario).
"""

import json
import os
from dataclasses import dataclass, asdict
from datetime import datetime

DATA_FILE = os.path.join(os.path.dirname(__file__), "data", "habitos.json")


@dataclass
class RegistroHabito:
    """Representa un registro individual de un hábito cumplido."""
    tipo_habito: str      # ej: "agua", "ejercicio", "sueno"
    cantidad: float        # ej: 8 (vasos), 30 (minutos), 7 (horas)
    unidad: str             # ej: "vasos", "minutos", "horas"
    fecha_hora: str        # ISO format: "2026-09-07T14:30:00"

    def to_dict(self):
        return asdict(self)


def _asegurar_archivo():
    """Crea el archivo de datos si todavía no existe."""
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f)


def cargar_datos() -> dict:
    """
    Carga todos los datos del archivo JSON.
    Estructura: { "user_id": [ {registro1}, {registro2}, ... ], ... }
    Si el archivo está corrupto o no se puede leer, se trata como vacío
    en vez de tumbar toda la aplicación.
    """
    _asegurar_archivo()
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def guardar_datos(datos: dict):
    """Guarda el diccionario completo de datos en el archivo JSON."""
    _asegurar_archivo()
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(datos, f, indent=2, ensure_ascii=False)
    except OSError as e:
        raise RuntimeError(f"No se pudieron guardar los datos de hábitos: {e}")


def agregar_registro(user_id: str, registro: RegistroHabito):
    """Agrega un nuevo registro de hábito para un usuario específico."""
    datos = cargar_datos()
    if user_id not in datos:
        datos[user_id] = []
    datos[user_id].append(registro.to_dict())
    guardar_datos(datos)


def obtener_registros(user_id: str, tipo_habito: str = None) -> list:
    """
    Devuelve los registros de un usuario.
    Si se especifica tipo_habito, filtra solo esos registros.
    """
    datos = cargar_datos()
    registros = datos.get(user_id, [])
    if tipo_habito:
        registros = [r for r in registros if r["tipo_habito"] == tipo_habito]
    return registros


# ---------------------------------------------------------------
# Perfil del usuario (edad, estatura, peso, sexo, nivel de actividad)
# ---------------------------------------------------------------
PROFILE_FILE = os.path.join(os.path.dirname(__file__), "data", "perfiles.json")


def _asegurar_archivo_perfiles():
    os.makedirs(os.path.dirname(PROFILE_FILE), exist_ok=True)
    if not os.path.exists(PROFILE_FILE):
        with open(PROFILE_FILE, "w", encoding="utf-8") as f:
            json.dump({}, f)


def cargar_perfiles() -> dict:
    """
    Si el archivo está corrupto o no se puede leer, se trata como vacío
    en vez de tumbar toda la aplicación.
    """
    _asegurar_archivo_perfiles()
    try:
        with open(PROFILE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def guardar_perfiles(perfiles: dict):
    _asegurar_archivo_perfiles()
    try:
        with open(PROFILE_FILE, "w", encoding="utf-8") as f:
            json.dump(perfiles, f, indent=2, ensure_ascii=False)
    except OSError as e:
        raise RuntimeError(f"No se pudieron guardar los perfiles: {e}")


def guardar_perfil(user_id: str, perfil: dict):
    """Guarda (o sobrescribe) el perfil de un usuario."""
    perfiles = cargar_perfiles()
    perfiles[user_id] = perfil
    guardar_perfiles(perfiles)


def obtener_perfil(user_id: str):
    """Devuelve el perfil del usuario, o None si no existe."""
    return cargar_perfiles().get(user_id)