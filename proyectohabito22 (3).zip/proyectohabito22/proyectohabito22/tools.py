"""
tools.py
Las herramientas personalizadas del Agente de Bienestar/Hábitos.

IMPORTANTE: Cada función tiene un docstring detallado porque Gemini
lee esa descripción (y los type hints) para decidir CUÁNDO y CÓMO
llamar a cada herramienta (function calling automático).
"""

from datetime import datetime, timedelta
from models import RegistroHabito, agregar_registro, obtener_registros, obtener_perfil

# ---------------------------------------------------------------
# Manejo del usuario actual (varios usuarios, un ID por sesión)
# ---------------------------------------------------------------
_usuario_actual = None

HABITOS_VALIDOS = {"agua", "ejercicio", "sueno", "estudiar"}


def set_usuario_actual(user_id: str):
    """Define qué usuario está usando el agente en esta sesión."""
    global _usuario_actual
    _usuario_actual = user_id


# Metas por defecto según el hábito (usadas por calcular_progreso y sugerir_meta)
METAS_DEFECTO = {
    "agua": {"cantidad": 8, "unidad": "vasos"},
    "ejercicio": {"cantidad": 30, "unidad": "minutos"},
    "sueno": {"cantidad": 8, "unidad": "horas"},
    "estudiar": {"cantidad": 60, "unidad": "minutos"},
}


def _validar_habito(tipo_habito: str) -> str | None:
    """Devuelve un mensaje de error si el tipo de hábito no es válido, o None si está bien."""
    if tipo_habito.lower() not in HABITOS_VALIDOS:
        return (
            f"'{tipo_habito}' no es un hábito reconocido. "
            f"Los hábitos disponibles son: agua, ejercicio, sueno."
        )
    return None


def _parse_fecha(fecha_str):
    """Convierte un fecha_hora ISO a datetime; devuelve None si el valor está corrupto."""
    try:
        return datetime.fromisoformat(fecha_str)
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------
# 1. registrar_habito
# ---------------------------------------------------------------
def registrar_habito(tipo_habito: str, cantidad: float, unidad: str) -> dict:
    """
    Guarda un registro cuando el usuario reporta que cumplió un hábito.
    Úsala cuando el usuario diga cosas como "tomé 2 vasos de agua",
    "hice 20 minutos de ejercicio" o "dormí 7 horas".

    Args:
        tipo_habito: Tipo de hábito. Debe ser "agua", "ejercicio" o "sueno".
        cantidad: Cantidad numérica reportada (ej. 2, 20, 7). Debe ser mayor a 0.
        unidad: Unidad de la cantidad (ej. "vasos", "minutos", "horas").

    Returns:
        Un diccionario confirmando que el registro fue guardado, o un
        diccionario con "error" si los datos no son válidos.
    """
    if _usuario_actual is None:
        return {"error": "No hay un usuario activo en la sesión."}

    error_habito = _validar_habito(tipo_habito)
    if error_habito:
        return {"error": error_habito}

    if not isinstance(cantidad, (int, float)) or isinstance(cantidad, bool) or cantidad <= 0:
        return {"error": "La cantidad debe ser un número mayor a 0."}

    if not isinstance(unidad, str) or not unidad.strip():
        return {"error": "Debes indicar una unidad válida (ej. 'vasos', 'minutos', 'horas')."}

    registro = RegistroHabito(
        tipo_habito=tipo_habito.lower(),
        cantidad=cantidad,
        unidad=unidad,
        fecha_hora=datetime.now().isoformat(),
    )
    agregar_registro(_usuario_actual, registro)

    return {
        "status": "guardado",
        "tipo_habito": tipo_habito.lower(),
        "cantidad": cantidad,
        "unidad": unidad,
    }


# ---------------------------------------------------------------
# 2. calcular_progreso
# ---------------------------------------------------------------
def calcular_progreso(tipo_habito: str, periodo: str = "dia") -> dict:
    """
    Calcula qué tanto ha cumplido el usuario un hábito en un período de tiempo,
    comparándolo contra la meta por defecto. Úsala cuando el usuario pregunte
    "¿cómo voy con el agua?" o "¿cumplí mi meta de ejercicio esta semana?".

    Args:
        tipo_habito: Tipo de hábito a evaluar ("agua", "ejercicio" o "sueno").
        periodo: Período a analizar, "dia" o "semana".

    Returns:
        Diccionario con el total acumulado, la meta y el porcentaje de cumplimiento.
    """
    if _usuario_actual is None:
        return {"error": "No hay un usuario activo en la sesión."}

    error_habito = _validar_habito(tipo_habito)
    if error_habito:
        return {"error": error_habito}

    if periodo not in ("dia", "semana"):
        periodo = "dia"

    tipo_habito = tipo_habito.lower()
    registros = obtener_registros(_usuario_actual, tipo_habito)

    ahora = datetime.now()
    if periodo == "semana":
        limite = ahora - timedelta(days=7)
    else:
        limite = ahora.replace(hour=0, minute=0, second=0, microsecond=0)

    registros_periodo = []
    fechas_periodo = []
    for r in registros:
        fecha = _parse_fecha(r.get("fecha_hora"))
        if fecha is not None and fecha >= limite:
            registros_periodo.append(r)
            fechas_periodo.append(fecha)

    if not registros_periodo:
        return {
            "tipo_habito": tipo_habito,
            "periodo": periodo,
            "total": 0,
            "mensaje": "No hay registros de este hábito en el período indicado.",
        }

    total = sum(r["cantidad"] for r in registros_periodo)
    meta_info = METAS_DEFECTO[tipo_habito]
    meta = meta_info["cantidad"]

    if periodo == "semana" and tipo_habito == "sueno":
        # El sueño se evalúa como promedio de horas por noche, no como suma semanal:
        # dormir 9 horas una sola noche no debería verse como "112% de la semana",
        # y registrar dos veces la misma noche no debería duplicar el promedio.
        dias_con_registro = len({f.date() for f in fechas_periodo})
        valor_mostrado = round(total / dias_con_registro, 1)
    else:
        # En semana, el resto de los hábitos comparan la suma contra la meta diaria x7.
        if periodo == "semana":
            meta = meta * 7
        valor_mostrado = round(total, 1)

    porcentaje = round((valor_mostrado / meta) * 100, 1) if meta else None

    return {
        "tipo_habito": tipo_habito,
        "periodo": periodo,
        "total": valor_mostrado,
        "unidad": meta_info["unidad"],
        "meta": meta,
        "porcentaje_cumplimiento": porcentaje,
    }


# ---------------------------------------------------------------
# 3. sugerir_meta
# ---------------------------------------------------------------
def sugerir_meta(tipo_habito: str, nivel: str = "principiante") -> dict:
    """
    Sugiere una meta diaria razonable para un hábito, según el nivel del usuario.
    Si el usuario tiene un perfil guardado con su peso, la meta de agua se
    calcula de forma personalizada (≈35ml por kg de peso corporal).
    Úsala cuando el usuario pida ayuda para definir una meta, ej. "¿cuánta agua
    debería tomar al día?" o "no sé cuánto ejercicio hacer".

    Args:
        tipo_habito: Tipo de hábito ("agua", "ejercicio" o "sueno").
        nivel: Nivel del usuario: "principiante", "intermedio" o "avanzado".

    Returns:
        Diccionario con la meta sugerida y una breve justificación.
    """
    error_habito = _validar_habito(tipo_habito)
    if error_habito:
        return {"error": error_habito}

    tipo_habito = tipo_habito.lower()
    base = METAS_DEFECTO[tipo_habito]

    if nivel not in ("principiante", "intermedio", "avanzado"):
        nivel = "principiante"

    ajuste = {"principiante": 0.7, "intermedio": 1.0, "avanzado": 1.3}[nivel]
    meta_sugerida = round(base["cantidad"] * ajuste, 1)
    personalizada = False

    # Si hay perfil con peso guardado, la meta de agua se calcula por peso corporal
    if tipo_habito == "agua" and _usuario_actual:
        perfil = obtener_perfil(_usuario_actual)
        if perfil and perfil.get("peso"):
            try:
                peso = float(perfil["peso"])
            except (TypeError, ValueError):
                peso = None
            if peso and peso > 0:
                litros = peso * 0.035  # ~35 ml por kg
                meta_sugerida = round((litros * 1000) / 250, 1)  # convertido a vasos de 250ml
                personalizada = True

    return {
        "tipo_habito": tipo_habito,
        "nivel": nivel,
        "meta_sugerida": meta_sugerida,
        "unidad": base["unidad"],
        "personalizada_por_peso": personalizada,
    }


# ---------------------------------------------------------------
# 4. generar_recordatorio
# ---------------------------------------------------------------
def generar_recordatorio(habito_pendiente: str, hora_del_dia: str = None) -> dict:
    """
    Genera un mensaje de recordatorio o motivación para un hábito que el
    usuario aún no ha cumplido hoy. Úsala cuando el usuario pida que le
    recuerden algo, o cuando calcular_progreso muestre que un hábito
    sigue en 0% durante el día.

    Args:
        habito_pendiente: El hábito que falta por cumplir (ej. "agua").
        hora_del_dia: Hora aproximada actual, ej. "tarde", "noche" (opcional).

    Returns:
        Diccionario con un mensaje de recordatorio personalizado.
    """
    mensajes = {
        "agua": "No has tomado suficiente agua hoy. ¡Un vaso ahora te ayuda a mantenerte activo!",
        "ejercicio": "Todavía no registras ejercicio hoy. Aunque sean 10 minutos, cuentan.",
        "sueno": "Recuerda dormir tus horas hoy para rendir mejor mañana.",
    }
    base = mensajes.get(
        habito_pendiente.lower(),
        f"No olvides cumplir tu hábito de {habito_pendiente} hoy.",
    )
    if hora_del_dia:
        base = f"({hora_del_dia}) {base}"

    return {"habito_pendiente": habito_pendiente, "recordatorio": base}


# ---------------------------------------------------------------
# 5. dar_consejo
# ---------------------------------------------------------------
def dar_consejo() -> dict:
    """
    Analiza el historial reciente (últimos 7 días) del usuario en todos
    sus hábitos y da un consejo de bienestar basado en patrones detectados,
    por ejemplo si lleva varios días sin cumplir el sueño o el ejercicio.
    Úsala cuando el usuario pida un consejo general o pregunte cómo va
    en general con sus hábitos.

    Returns:
        Diccionario con un consejo específico basado en los datos.
    """
    if _usuario_actual is None:
        return {"error": "No hay un usuario activo en la sesión."}

    ahora = datetime.now()
    limite = ahora - timedelta(days=7)
    consejos = []

    for tipo in METAS_DEFECTO:
        registros = obtener_registros(_usuario_actual, tipo)
        recientes = []
        fechas_validas = set()
        for r in registros:
            fecha = _parse_fecha(r.get("fecha_hora"))
            if fecha is not None and fecha >= limite:
                recientes.append(r)
                fechas_validas.add(fecha.date())
        dias_con_registro = len(fechas_validas)
        if dias_con_registro == 0:
            consejos.append(
                f"No tienes registros de {tipo} en los últimos 7 días. Intenta empezar hoy con algo pequeño."
            )
        elif dias_con_registro < 3:
            consejos.append(
                f"Llevas pocos días registrando {tipo} esta semana ({dias_con_registro} días). Intenta ser más constante."
            )

    if not consejos:
        return {"consejo": "Vas muy bien con tus hábitos esta semana. ¡Sigue así!"}

    return {"consejo": " ".join(consejos)}


# ---------------------------------------------------------------
# 6. recomendar_hora_dormir
# ---------------------------------------------------------------
def recomendar_hora_dormir(hora_despertar: str, horas_meta: float = 8) -> dict:
    """
    Recomienda a qué hora debería acostarse el usuario según la hora en que
    necesita despertarse y su meta de horas de sueño. Úsala cuando el usuario
    pregunte algo como "¿a qué hora me debería acostar si me levanto a las 6?".

    Args:
        hora_despertar: Hora en formato "HH:MM" de 24 horas (ej. "06:30").
        horas_meta: Horas de sueño que quiere dormir (por defecto 8).

    Returns:
        Diccionario con la hora recomendada para dormir, o un error si el
        formato de hora no es válido.
    """
    try:
        despertar = datetime.strptime(hora_despertar, "%H:%M")
    except ValueError:
        return {"error": f"'{hora_despertar}' no es una hora válida. Usa el formato HH:MM, ej. 06:30."}

    if horas_meta <= 0 or horas_meta > 14:
        return {"error": "Las horas meta de sueño deben estar entre 0 y 14."}

    hora_dormir = despertar - timedelta(hours=horas_meta)

    return {
        "hora_despertar": hora_despertar,
        "horas_meta": horas_meta,
        "hora_recomendada_dormir": hora_dormir.strftime("%H:%M"),
    }


# ---------------------------------------------------------------
# 7. historial_por_dia (uso interno del dashboard, no es tool del LLM)
# ---------------------------------------------------------------
def historial_por_dia(dias: int = 7) -> dict:
    """
    Agrupa los registros de los últimos N días por fecha y tipo de hábito.
    No se expone al LLM: la usa directamente el dashboard para pintar
    la ventana de 'Registro de días'.
    """
    if _usuario_actual is None:
        return {"dias": []}

    hoy = datetime.now().date()
    base = {}
    for offset in range(dias):
        dia = hoy - timedelta(days=offset)
        base[dia.isoformat()] = {"agua": 0, "ejercicio": 0, "sueno": 0, "estudiar": 0}

    for tipo in METAS_DEFECTO:
        for r in obtener_registros(_usuario_actual, tipo):
            fecha_dt = _parse_fecha(r.get("fecha_hora"))
            if fecha_dt is None:
                continue
            fecha = fecha_dt.date().isoformat()
            if fecha in base:
                base[fecha][tipo] += r["cantidad"]

    dias_ordenados = sorted(base.keys(), reverse=True)
    return {"dias": [{"fecha": d, **base[d]} for d in dias_ordenados]}