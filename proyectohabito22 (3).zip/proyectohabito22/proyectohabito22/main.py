"""
main.py
Backend del Agente de Bienestar/Hábitos.

Responsabilidades:
- Exponer un endpoint /chat que recibe mensajes del usuario.
- Mantener una conversación por usuario (contexto conversacional).
- Usar Gemini con "function calling" automático: el modelo decide
  cuál de las herramientas usar según el mensaje del usuario.
- Manejar errores de forma controlada (API caída, tool sin datos, etc.)
"""

import os
import traceback
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

from google import genai
from google.genai import types

import tools as agent_tools
import models

# -----------------------------------------------------------------
# Configuración inicial
# -----------------------------------------------------------------
load_dotenv()

API_KEY = os.getenv("GOOGLE_API_KEY")
if not API_KEY:
    raise RuntimeError(
        "Falta GOOGLE_API_KEY en el archivo .env. Copia .env.example a .env y agrega tu llave."
    )

client = genai.Client(api_key=API_KEY)
MODEL_NAME = "gemini-3.5-flash-lite"

SYSTEM_INSTRUCTION = """
Eres un Agente de Bienestar/Hábitos. Ayudas a las personas a llevar seguimiento
de hábitos saludables: agua, ejercicio y sueño.

Reglas importantes:
1. Cuando el usuario reporte que cumplió un hábito (ej. "tomé agua", "hice ejercicio",
   "dormí X horas"), usa la herramienta registrar_habito.
2. Cuando pregunte por su progreso o cumplimiento, usa calcular_progreso.
3. Cuando pida ayuda para definir una meta, usa sugerir_meta.
4. Cuando pida un recordatorio o note que le falta algo por hacer, usa generar_recordatorio.
5. Cuando pida un consejo general de bienestar, usa dar_consejo.
6. Cuando pregunte a qué hora acostarse según la hora en que despierta, usa recomendar_hora_dormir.
6b. Cuando el usuario reporte haber estudiado (ej. "estudié 1 hora", "estudié 45 minutos"),
   usa registrar_habito con tipo_habito='estudiar', cantidad en minutos y unidad='minutos'.
7. Si una herramienta devuelve un campo "error", explícale al usuario de forma clara
   y amable qué pasó, sin inventar datos que no tengas.
8. Si el usuario pregunta algo que no tiene relación con hábitos de bienestar
   (agua, ejercicio, sueño), indícale amablemente que ese tema está fuera de tu
   alcance y qué sí puedes ayudarle a hacer.
9. Mantén el contexto de la conversación: si el usuario dice "y del ejercicio?"
   después de hablar de agua, entiende que sigue en el mismo tema de hábitos.
10. Nunca inventes números o registros que no vengan de las herramientas.
11. Responde siempre en texto plano, SIN usar markdown (nada de asteriscos, guiones,
    numeración ni encabezados) y SIN emojis. El chat solo muestra texto simple, así
    que cualquier símbolo de formato se ve como texto suelto y queda desprolijo.
Responde siempre en español, de forma breve, cálida y clara.
"""

TOOLS = [
    agent_tools.registrar_habito,
    agent_tools.calcular_progreso,
    agent_tools.sugerir_meta,
    agent_tools.generar_recordatorio,
    agent_tools.dar_consejo,
    agent_tools.recomendar_hora_dormir,
]

GEN_CONFIG = types.GenerateContentConfig(
    system_instruction=SYSTEM_INSTRUCTION,
    tools=TOOLS,
)

# -----------------------------------------------------------------
# Manejo de conversaciones (una por usuario, en memoria)
# -----------------------------------------------------------------
# user_id -> objeto "chat" de Gemini (mantiene el historial automáticamente)
conversaciones = {}


def obtener_chat(user_id: str):
    """Devuelve el chat existente del usuario o crea uno nuevo."""
    if user_id not in conversaciones:
        conversaciones[user_id] = client.chats.create(
            model=MODEL_NAME,
            config=GEN_CONFIG,
        )
    return conversaciones[user_id]


# -----------------------------------------------------------------
# App Flask
# -----------------------------------------------------------------
app = Flask(__name__, static_folder="static")
CORS(app)


@app.route("/")
def login_page():
    return send_from_directory(app.static_folder, "login.html")


@app.route("/app")
def app_page():
    return send_from_directory(app.static_folder, "app.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    user_id = (data.get("user_id") or "").strip()
    mensaje = (data.get("message") or "").strip()

    # --- Validación de entrada ---
    if not user_id:
        return jsonify({"error": "Falta el user_id."}), 400
    if not mensaje:
        return jsonify({"error": "El mensaje está vacío."}), 400

    # El agente siempre opera sobre el usuario correcto
    agent_tools.set_usuario_actual(user_id)

    try:
        chat_session = obtener_chat(user_id)
        respuesta = chat_session.send_message(mensaje)
        texto = respuesta.text or "No pude generar una respuesta esta vez, intenta de nuevo."
        return jsonify({"reply": texto})

    except Exception as e:
        # No inventamos una respuesta: avisamos claramente que algo falló.
        print("Error en /chat:", traceback.format_exc())
        return jsonify({
            "error": "Hubo un problema al procesar tu mensaje. Intenta de nuevo en un momento.",
            "detalle": str(e),
        }), 500


@app.route("/progreso", methods=["GET"])
def progreso():
    """
    Devuelve el progreso para los 3 hábitos, directamente desde las tools
    (sin pasar por el LLM). El parámetro periodo ("dia" o "semana") controla
    si se compara contra la meta diaria o semanal. Usado por el dashboard.
    """
    user_id = (request.args.get("user_id") or "").strip()
    periodo = request.args.get("periodo", "dia")
    if periodo not in ("dia", "semana"):
        periodo = "dia"
    if not user_id:
        return jsonify({"error": "Falta el user_id."}), 400

    agent_tools.set_usuario_actual(user_id)
    try:
        resultado = {
            "agua": agent_tools.calcular_progreso("agua", periodo),
            "ejercicio": agent_tools.calcular_progreso("ejercicio", periodo),
            "sueno": agent_tools.calcular_progreso("sueno", periodo),
            "estudiar": agent_tools.calcular_progreso("estudiar", periodo),
        }
        if periodo == "dia":
            resultado["consejo"] = agent_tools.dar_consejo()
        return jsonify(resultado)
    except Exception as e:
        print("Error en /progreso:", traceback.format_exc())
        return jsonify({"error": "No se pudo calcular el progreso.", "detalle": str(e)}), 500


@app.route("/historial", methods=["GET"])
def historial():
    """Devuelve el historial de los últimos N días para la ventana de registro."""
    user_id = (request.args.get("user_id") or "").strip()
    dias = int(request.args.get("dias", 7))
    if not user_id:
        return jsonify({"error": "Falta el user_id."}), 400

    agent_tools.set_usuario_actual(user_id)
    try:
        return jsonify(agent_tools.historial_por_dia(dias))
    except Exception as e:
        print("Error en /historial:", traceback.format_exc())
        return jsonify({"error": "No se pudo cargar el historial.", "detalle": str(e)}), 500


@app.route("/perfil", methods=["GET"])
def ver_perfil():
    """Devuelve el perfil guardado del usuario (edad, estatura, peso, sexo, actividad)."""
    user_id = (request.args.get("user_id") or "").strip()
    if not user_id:
        return jsonify({"error": "Falta el user_id."}), 400
    return jsonify({"perfil": models.obtener_perfil(user_id)})


@app.route("/perfil", methods=["POST"])
def guardar_perfil_ruta():
    """Guarda o actualiza el perfil del usuario."""
    data = request.get_json(silent=True) or {}
    user_id = (data.get("user_id") or "").strip()
    if not user_id:
        return jsonify({"error": "Falta el user_id."}), 400

    perfil = {
        "edad": data.get("edad"),
        "estatura": data.get("estatura"),
        "peso": data.get("peso"),
        "sexo": data.get("sexo"),
        "nivel_actividad": data.get("nivel_actividad"),
    }
    try:
        models.guardar_perfil(user_id, perfil)
        return jsonify({"status": "guardado", "perfil": perfil})
    except Exception as e:
        print("Error en /perfil:", traceback.format_exc())
        return jsonify({"error": "No se pudo guardar el perfil.", "detalle": str(e)}), 500


@app.route("/reset", methods=["POST"])
def reset():
    """Reinicia la conversación de un usuario (borra el contexto, no los registros)."""
    data = request.get_json(silent=True) or {}
    user_id = (data.get("user_id") or "").strip()
    if user_id in conversaciones:
        del conversaciones[user_id]
    return jsonify({"status": "conversacion reiniciada"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)